/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TimeProviderConfig {
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/time/0.14.0/docs#alias TimeProvider#alias}
    */
    readonly alias?: string;
}
import { TimeProviderFunctions } from '../provider-functions/index';
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/time/0.14.0/docs time}
*/
export declare class TimeProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "time";
    /**
    * Generates CDKTN code for importing a TimeProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TimeProvider to import
    * @param importFromId The id of the existing TimeProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/time/0.14.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TimeProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/time/0.14.0/docs time} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TimeProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TimeProviderConfig);
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _functions?;
    /**
    * Provider-defined functions of the time provider.
    */
    get functions(): TimeProviderFunctions;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
